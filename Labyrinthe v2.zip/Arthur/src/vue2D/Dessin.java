// Dessin.java
package vue2D;

import graphe.Graphe;

import java.awt.*;
import java.util.*;
import javax.swing.*;

import personnage.Personnage;
import personnage.PersonnageClavier;
import personnage.PersonnageDefaut;
import application.*;
import java.awt.event.*;

import labyrinthe.Salle;
import labyrinthe.grille.*;

public class Dessin extends JComponent {

    public static final int unite = 15;
    protected LabyrintheGrille labyrinthe;
    protected Personnage bob;
    protected Graphe graphe;
    SalleCarree entree;
    SalleCarree sortie;
    private ArrayList<Case> sallesVisitees = new ArrayList<Case>();
    
    public Dessin(LabyrintheGrille labyrinthe,Personnage bob, Graphe graphe)
    {
    	this.labyrinthe=labyrinthe;
    	this.graphe = graphe;
    	entree =  (SalleCarree) labyrinthe.getEntree();
    	sortie =  (SalleCarree) labyrinthe.getSortie();
    	this.bob=bob;
    	setPreferredSize(new Dimension(labyrinthe.getLargeur()*unite, 
    									labyrinthe.getHauteur()*unite));
    	// on ajoute un ecouteur sur le clavier attache au dessin du labyrinthe								
    	addKeyListener((KeyListener) bob);	
    }
    
    public void dessinFond(Graphics g){
    	// fond noir
    	g.setColor(Color.black);
    	g.fillRect(0,0,this.getWidth(), this.getHeight());
    }
    
    
    public void dessinSalles(Graphics g){
    	// salles
    	Collection<Salle> salles=labyrinthe.getSalles();
    	for (Salle s: salles)
    	{
    		int i = ((SalleCarree) s).getLigne();
    		int j = ((SalleCarree) s).getColonne();
    		g.setColor(Color.black);
			g.fillRect(j*unite,i*unite,unite,unite);
			
			Salle sBob = bob.getPosition();
			int iBob = ((SalleCarree) sBob).getLigne();
			int jBob = ((SalleCarree) sBob).getColonne();
			
			int distance = Math.abs(iBob-i) + Math.abs(jBob -j);
			
			
			if (distance < 9)
			{
				g.setColor(new Color(255-distance*20,215-distance*20,distance*5));
				g.fillRect(j*unite, i*unite,unite,unite);
				
			}
    	}
    }
    
    public void dessinSallesVisitees(Graphics g){
		// dessin des salles connues
    	Case c = (Case) bob.getPosition();
    	if (!sallesVisitees.contains(c)) // maj des salles visitees
    		sallesVisitees.add(c);
    	for (Case s : sallesVisitees){
    		if(s!=c)
    		{
    			int j = s.getColonne(); 
        		int i = s.getLigne();
        		g.setColor(new Color(100,100,0));
    			g.fillRect(j*unite,i*unite,unite,unite);
    		}
    	}
    }	
    
    public void dessinCheminSortie(Graphics g){

    	for (Salle s : graphe.getCheminSortie()){

    			int j = ((SalleCarree) s).getColonne(); 
        		int i = ((SalleCarree) s).getLigne();
        		g.setColor(new Color(200,100,0));
    			g.fillRect(j*unite,i*unite,unite,unite);
    		
    	}
    }	
	
    public void dessinEntreeSortie(Graphics g){
    	g.setColor(new Color(110,90,50));
    	g.fillRect(entree.getColonne()*unite, entree.getLigne()*unite, unite,unite);
    	g.setColor(new Color(0,200,255));
    	g.fillRect(sortie.getColonne()*unite, sortie.getLigne()*unite, unite,unite);
    }
    
    public void majCoordonneesGraphiquesHeros(){
    	Case s = (Case) bob.getPosition();
    	int xpixDestination = s.getColonne()*unite;
    	int ypixDestination = s.getLigne()*unite;
    	
    	int x = ((PersonnageClavier) bob).xpix;
    	int y = ((PersonnageClavier) bob).ypix;
    	((PersonnageDefaut) bob).peutSeDeplacer = ((x==xpixDestination)&&(y==ypixDestination));
    	//((PersonnageDefaut) bob).peutSeDeplacer = true;

    	if(x>xpixDestination)
    	{
    		((PersonnageClavier) bob).xpix--;
    		return;
    	}
    	
    	if(x<xpixDestination)
    	{
    		((PersonnageClavier) bob).xpix++;
    		return;
    	}
    	
    	if(y>ypixDestination)
    	{
    		((PersonnageClavier) bob).ypix--;
    		return;
    	}
    	
    	if(y<ypixDestination)
    	{
    		((PersonnageClavier) bob).ypix++;
    		return;
    	}
    }
   

    public void dessinHeros(Graphics g){
    	
    	g.setColor(new Color(125,40,255));
    	majCoordonneesGraphiquesHeros();
    	int x = ((PersonnageClavier) bob).xpix;
    	int y = ((PersonnageClavier) bob).ypix;
    	g.fillRect(x, y,unite,unite);
    }
    
    public void paintComponent(Graphics g)
    {
    	dessinFond(g);
    	dessinSalles(g);
    	dessinSallesVisitees(g);
    	dessinCheminSortie(g);
    	dessinEntreeSortie(g);
    	dessinHeros(g);
    }
}
