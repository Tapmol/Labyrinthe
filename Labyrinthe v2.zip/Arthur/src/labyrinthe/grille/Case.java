package labyrinthe.grille;

import labyrinthe.Salle;

public interface Case extends Salle{
	 public abstract int getLigne();
	 public abstract int getColonne();
}
