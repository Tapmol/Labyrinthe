package labyrinthe.grille;

import labyrinthe.Labyrinthe;

public interface LabyrintheGrille extends Labyrinthe{
	 public abstract int getHauteur();
	 public abstract int getLargeur();
}
