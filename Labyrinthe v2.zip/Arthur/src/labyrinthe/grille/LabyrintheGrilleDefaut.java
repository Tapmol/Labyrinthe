package labyrinthe.grille;

import java.io.File;
import java.util.*;

import labyrinthe.Salle;
import personnage.Personnage;

public class LabyrintheGrilleDefaut implements LabyrintheGrille
{

	protected int hauteur;
    protected int largeur;
    protected Salle[][] sommets;
    protected Salle entree;
    protected Salle sortie;
    
    // cree le labyrinthe
    public void creerLabyrinthe(String file)
    {
		// À parir d'un fichier !
		Scanner sc=null;
		try
		{
		    sc = new Scanner(new File(file));
		}
		catch(Exception e){ System.out.println(e);}
	
		// les deux premiers entiers
		// hauteur largeur
		hauteur=sc.nextInt();
		largeur=sc.nextInt();
		sommets = new SalleCarree[hauteur][largeur];
	
		// les deux entiers suivants
		// coord entree
		int ligneEntree=sc.nextInt();
		int colonneEntree=sc.nextInt();
		entree = new SalleCarree(ligneEntree,colonneEntree);
		// les deux entiers suivants
		// coord sortie
		int ligneSortie=sc.nextInt();
		int colonneSortie=sc.nextInt();
		sortie = new SalleCarree(ligneSortie,colonneSortie);
	
		// on initialise la matrice
		// null signifie : salle non existante
		for(int i=0;i<hauteur;i++)
		    for(int j=0;j<largeur;j++)
			sommets[i][j]=null;
		
		// ajout des entree et sortie
		sommets[ligneEntree][colonneEntree]=entree;
		sommets[ligneSortie][colonneSortie]=sortie;
	
		// ajout des autres salles
		while(sc.hasNext())
		{
		    int ligne=sc.nextInt();
		    int colonne=sc.nextInt();
		    sommets[ligne][colonne]=new SalleCarree(ligne,colonne);
		}
    }
    

    // renvoie les salles accessibles par bob
    public Collection<Salle> sallesAccessibles(Salle s)
    {
    	Collection<Salle> sa = new ArrayList<Salle>();
    	SalleCarree tmp=  (SalleCarree) s;
    	Salle ad;
    	try
    	{
    		ad=sommets[tmp.getLigne()-1][tmp.getColonne()];
    		if(ad != null)
    			sa.add(ad); // haut
    		ad=sommets[tmp.getLigne()][tmp.getColonne()+1];
    		if(ad != null)
    			sa.add(ad); // droite
    		ad=sommets[tmp.getLigne()+1][tmp.getColonne()];
    		if(ad != null)
    			sa.add(ad); // bas 
    		ad=sommets[tmp.getLigne()][tmp.getColonne()-1];
    		if(ad != null)
    			sa.add(ad); // gauche
    	}
    	catch(Exception e){}
    	return sa;
    }


    public Collection<Salle> getSalles()
    {
    	ArrayList<Salle> al = new ArrayList<Salle>();
    	for (int i=0; i<getHauteur(); i++)
    		for (int j=0; j<getLargeur(); j++)
    			if (sommets[i][j]!=null)
    				al.add(sommets[i][j]);
    	return al;
    }
    
    public int getHauteur()
    {
    	return hauteur;
    }

    public int getLargeur()
    {
    	return largeur;
    }
    

	public void entrer(Personnage bob)
	{
    	entree.recevoir(bob);
    }

    public boolean sortir(Personnage bob){
		return (bob.getPosition()==sortie);
    }

	public Salle getEntree(){
		return entree;
	}

	public Salle getSortie(){
		return sortie;
	}

}
