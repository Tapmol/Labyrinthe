package labyrinthe.grille;

import graphe.Sommet;
import labyrinthe.Salle;
import personnage.*;

public class SalleCarree implements Case{
	private int x;
    private int y;
    private boolean flag = false;
    private int parcouru;
    private Salle sallePrecedente;
    private Sommet sommet = null;
    
    public SalleCarree(int colonne,int ligne)
    {
    	this.x=colonne;
    	this.y=ligne;
    }
    
    public boolean recevoir(Personnage bob)
    {

    		bob.setPosition(this);

    	return true;
	}
    
    public void setParcouru(int parcouru)
    {
    	this.parcouru = parcouru;
    }
    
    public int getParcouru()
    {
    	return parcouru;
    }
    
    public void setSallePrecedente(Salle sallePrecedente)
    {
    	this.sallePrecedente = sallePrecedente;
    }
    
    public Salle getSallePrecedente()
    {
    	return sallePrecedente;
    }
    
    public int getLigne()
    {
    	return x;
    }
    
    public int getColonne()
    {
    	return y;
    }
    public String toString()
    {
		return "Salle: "+x+","+y;
	}

	public void setFlag(boolean flag) {
		this.flag = flag;
	}

	public boolean isFlag() {
		return flag;
	}

	public void setSommet(Sommet sommet) {
		this.sommet = sommet;
	}

	public Sommet getSommet() {
		return sommet;
	}
}
