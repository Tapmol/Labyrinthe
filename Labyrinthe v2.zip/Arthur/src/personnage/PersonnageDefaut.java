// personnageDefaut.java
// implémentation minimaliste de Personnage
// il sera ensuite conseillé de dériver cette classe afin
// de masquer la methode "faitSonChoix"

package personnage;

import java.util.*;
import java.io.*;


import labyrinthe.Salle;
import labyrinthe.grille.Case;

public abstract class PersonnageDefaut implements Personnage {
    private Salle salleCourante;
    public boolean peutSeDeplacer=true;
    
    public PersonnageDefaut(){}
    
    public abstract Salle faitSonChoix(Collection<Salle> sallesAccessibles);

	public Salle getPosition() {
		return salleCourante;
	}

	public void setPosition(Salle salleCourante) {
		this.salleCourante = salleCourante;
	}
}
