// Personnage.java
package personnage;
import java.util.*;

import labyrinthe.Salle;


public interface Personnage {
    // renvoie une salle parmi sallesAccesibles
    public Salle faitSonChoix(Collection<Salle> sallesAccessibles);

    // renvoie sa position courante
    public Salle getPosition();
    
    // definit sa position courante
    public void setPosition( Salle s);
    
}
