package graphe;

import java.util.Collection;
import java.util.HashSet;

import labyrinthe.Salle;

/**
 * Un Sommet represente une salle dans un graphe
 * @author Sohel Zerdoumi
 * @author Patrick Michelet
 *
 */
public class Sommet {
	private int indice = 100000;
	private Salle salle = null;
	private Collection<Sommet> voisins = new HashSet<Sommet>();
	
	
	public Sommet( Salle s)
	{
		this.setSalle(s);
	}
	
	public void addVoisin(Sommet s)
	{
		voisins.add(s);
	}
	
	/**
	 * Cherche le voisin ayant le plus petit indice
	 * @return voisin ayant le plus petit indice
	 */
	public Sommet plusPetitVoisin()
	{
		Sommet petitVoisin = voisins.iterator().next();
		for(Sommet v : voisins )
		{
			if( petitVoisin.getIndice() > v.getIndice())
				petitVoisin = v;
		}
		
		return petitVoisin;
	}


	public Salle getSalle() {
		return salle;
	}

	protected void setSalle(Salle salle) {
		this.salle = salle;
	}
	
	public Collection<Sommet> getVoisins()
	{
		 return voisins;
	}
	
	public int getIndice() {
		return indice;
	}

	public void setIndice(int i) {
		this.indice = i;
	}
}
