package graphe;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;

import personnage.Personnage;

import labyrinthe.Salle;
import labyrinthe.grille.LabyrintheGrilleDefaut;
import labyrinthe.grille.SalleCarree;

/**
 * Un graphe represente un labyrinthe.
 * Chaque salle du labyrinthe est un sommet.
 * Un graphe permet de trouver rapidement la sortie du labyrinthe depuis une salle donnee
 * @author Sohel Zerdoumi
 * @author Patrick Michelet
 *
 */
public class Graphe {
	private ArrayList<Sommet> sommets = new ArrayList<Sommet>();
	private ArrayList<Salle>  cheminSortie = new ArrayList<Salle>();
	private Personnage bob = null;

	private LabyrintheGrilleDefaut labyrinthe = null;
	private Sommet sommetSortie = null;
	private Sommet sommetEntree = null;
	
	public Graphe(LabyrintheGrilleDefaut labyrinthe, Personnage bob)
	{
		this.bob = bob;
		this.labyrinthe = labyrinthe;

	}
	
	public void nouveauGraphe()
	{
		genererGraphe( );
		resetSommets();
		ponderation();		
		trouverCheminSortie();

	}
	
	/**
	 * On parcours chaque  salle et on en fait un sommet
	 */
	private void genererGraphe()
	{
		int i = 0;

		for(  Salle currentSalle : labyrinthe.getSalles() )
		{
			Sommet sommet = new Sommet(currentSalle); 
			if( currentSalle == labyrinthe.getSortie())
				sommetSortie = sommet;
			if( currentSalle == labyrinthe.getEntree())
				setSommetEntree(sommet);
			((SalleCarree) currentSalle).setSommet(sommet);
			sommets.add(sommet);
	
		}

		/*
		 * On met a jours la liste des voisins de chaque sommet
		 */
		for(  Sommet s : sommets )
		{
			for( Salle salleVoisine : this.labyrinthe.sallesAccessibles(s.getSalle()))
			{
				i++;
				s.addVoisin( ((SalleCarree) salleVoisine).getSommet() );
			}		
		}	
		
	}
	
	/**
	 * On pondere chaque sommet en fonction du nombre de coup necessaire 
	 * pour atteindre la sortie
	 */
	private void  ponderation()
	{ 
		Collection<Cellule> old_cellules = new HashSet<Cellule>();
		old_cellules.add( new Cellule(  sommetSortie, 0  ));
		/*
		 * tant qu'il existe des cellules, on les  fait evoluer
		 */
		while( old_cellules.size() > 0 )
		{
			Collection<Cellule> new_cellules = new HashSet<Cellule>();
			
			/*
			 * On fait evoluer les anciennes cellules
			 */
			for( Cellule c : old_cellules )
			{
					new_cellules.addAll(c.next());
			}
			old_cellules = new_cellules;
		}
	}	
	
	/**
	 * Remet à zero les indices de toutes les cases
	 */
	private void resetSommets()
	{
		for( Sommet s : sommets)
		{
			s.setIndice(100000);
		}
	}
	
	
	public void trouverCheminSortie()
	{
		cheminSortie = new ArrayList<Salle>();
		trouverCheminSortie(((SalleCarree) bob.getPosition()).getSommet());
	}
	
	/**
	 * Trouve le chemin vers la sortie
	 * @param s Sommet actuel
	 */
	private void trouverCheminSortie(Sommet s)
	{
	
		if( s.getIndice() == 0 )
			return;
		Sommet voisin = s.plusPetitVoisin();
		cheminSortie.add(voisin.getSalle());
		trouverCheminSortie(voisin);
	}
	
	public ArrayList<Salle> getCheminSortie()
	{
		return cheminSortie;
	}

	public void setSommetEntree(Sommet sommetEntree) {
		this.sommetEntree = sommetEntree;
	}

	public Sommet getSommetEntree() {
		return sommetEntree;
	}

}
