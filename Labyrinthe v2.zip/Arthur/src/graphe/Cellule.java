package graphe;

import java.util.Collection;
import java.util.HashSet;

/**
 * Une cellule donne naissance à autant de cellule qu'il y a de case libre à coté
 * 
 * @author Sohel Zerdoumi
 * @author Patrick Michelet
 */
public class Cellule {
	private Sommet currentSommet = null;
	
	public Cellule( Sommet s, int i )
	{
		if( i > 1000)
			System.out.println(i);

		currentSommet = s;
		currentSommet.setIndice(i);
	}
	
	/**
	 * Créé de nouvelles cellules autour de celle ci
	 * @return cellules voisines
	 */
	public Collection<Cellule> next()
	{
		HashSet<Cellule> childs = new HashSet<Cellule>();
		/*
		 * On parcourt tous les voisins de la cellule
		 */
		for( Sommet s : currentSommet.getVoisins())
		{
			/*
			 * Si un des voisins a un indice plus grand que le notre, on créé une nouvelle cellule
			 */
			if( s.getIndice() > currentSommet.getIndice() )
			{
				childs.add( new Cellule( s, currentSommet.getIndice() + 1 ));
			}
		}
		
		return childs;
	}

	public Sommet getCurrentSommet() {
		return currentSommet;
	}
	
	
}
