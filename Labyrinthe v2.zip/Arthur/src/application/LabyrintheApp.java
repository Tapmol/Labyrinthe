// LabyrintheApp.java
package application;

import graphe.Graphe;

import java.util.*;
import javax.swing.*;

import personnage.*;
import labyrinthe.Labyrinthe;
import labyrinthe.Salle;
import labyrinthe.grille.Case;
import labyrinthe.grille.LabyrintheGrille;
import labyrinthe.grille.LabyrintheGrilleDefaut;

import vue2D.*;

public class LabyrintheApp
{

	public LabyrintheApp(Labyrinthe laby)
	{}
	
    public static void main (String[] args)
    {
		// modele
		Labyrinthe labyrinthe = new LabyrintheGrilleDefaut();
		if (args.length==0)
			labyrinthe.creerLabyrinthe("labys/laby3.txt");
		else
			labyrinthe.creerLabyrinthe(args[0]);
		Personnage bob = new PersonnageClavier();
		labyrinthe.entrer(bob);
		int cpt=0;

		// vue
		JFrame.setDefaultLookAndFeelDecorated(true);
		JFrame frame = new JFrame("Labyrinthe");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Graphe graphe = new Graphe((LabyrintheGrilleDefaut) labyrinthe , bob);
		graphe.nouveauGraphe();
		Dessin dessin = new Dessin((LabyrintheGrille)labyrinthe,bob, graphe);
		
		dessin.setFocusable(true);
		dessin.requestFocus();
		frame.setContentPane(dessin);
		frame.pack();
		frame.setVisible(true);
	
		while(!labyrinthe.sortir(bob))
		{
		    Collection<Salle> sallesAccessibles = labyrinthe.sallesAccessibles( bob.getPosition());
		    Salle destination = bob.faitSonChoix(sallesAccessibles); // on demande au heros de faire son choix de salle
		    if (destination!=bob.getPosition())
		    	{
		    		destination.recevoir(bob); // deplacement
		    		graphe.trouverCheminSortie();
		    	}
		    //rafraichissement de la vue
		    frame.repaint();
		    // on fait une pause
		    try{Thread.currentThread().sleep(10);}
		    catch(InterruptedException ie){}
		    
		}
    }
}
