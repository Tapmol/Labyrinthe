package graphes;

import java.util.ArrayList;

import labyrinthe.*;
import labyrinthe.graphe.SalleSommetCarree;


public class Graphe {

	public Labyrinthe labyrinthe;
	
	public int n;
	
	public ArrayList<Sommet> sommets;
	public ArrayList<Arc> arcs;
	
	public int [][]distances;
	
	public Graphe(Labyrinthe laby)
	{
		n = 0;
		sommets = new ArrayList<Sommet>();
		arcs =  new ArrayList<Arc>();
		this.labyrinthe = laby;
	}
	

	public boolean estAdjacent(Sommet u, Sommet v)
	{
		for (Arc arc: arcs)
		{
			if ((arc.a==u)&&(arc.b==v))
				return true;
			if ((arc.a==v)&&(arc.b==u))
				return true;
		}
		return false;
	}
	

	
	public ArrayList<Sommet> plusCourtChemin(Sommet entree, Sommet sortie)
	{
		ArrayList<Sommet> sallesVoisines = new ArrayList<Sommet>();
		ArrayList<Sommet> chemin = new ArrayList<Sommet>();
		ArrayList<Sommet> sallesNonVisitees = new ArrayList<Sommet>();
		
		Sommet s1, s2;
		
		for(Sommet s : sommets)
		{
			((SalleSommetCarree) s).setParcouru(Integer.MAX_VALUE-1);
		}
		
		((SalleSommetCarree) entree).setParcouru(0);
		sallesNonVisitees = sommets;
		
		while(!sallesNonVisitees.isEmpty())
		{
			s1 = minimum(sallesNonVisitees);
			sallesNonVisitees.remove(s1);
			
			sallesVoisines = (ArrayList<Sommet>) labyrinthe.sallesAccessibles((Sommet) s1);
			
			for(Sommet s : sallesVoisines)
			{
				int s1_parcouru = ((SalleSommetCarree) s1).getParcouru();
				
				if(((SalleSommetCarree) s).getParcouru() > (s1_parcouru+1))
				{
					((SalleSommetCarree) s).setParcouru(s1_parcouru+1);
					((SalleSommetCarree) s).setSallePrecedente(s1);
					sallesNonVisitees.add(s);
				}
				
			}
		}
		chemin.clear();
		s2 = sortie;
		
		while(s2 != entree)
		{
			chemin.add(s2);
			s2 = ((SalleSommetCarree) s2).getSallePrecedente();
		}
		
		chemin.add(entree);
		return chemin;
	}
	
	private Sommet minimum(ArrayList<Sommet> Sommet)
	{
		int tmp = Integer.MAX_VALUE;
		int parcouru;
		Sommet smin = null;
		
		for(Sommet s : sommets)
		{
			parcouru = ((SalleSommetCarree) s).getParcouru();
			if(parcouru < tmp)
			{
				tmp = parcouru;
				smin = s;
			}
		}
		return smin;
	}
	
	public void distancesLabyrinthe()
	{
		distances = new int[n][n];
		for(Sommet s1 : sommets)
		{
			for(Sommet s2 : sommets)
			{
				if(s1.id != s2.id)
				{
					int longueur = plusCourtChemin(s1,s2).size();
					distances[s1.id][s2.id] = longueur;
				}
			}
		}
	}
}




