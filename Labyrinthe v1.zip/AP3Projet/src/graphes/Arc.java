package graphes;

public class Arc {
	public Sommet a;
	public Sommet b;
	
	
	public Arc(Sommet a, Sommet b)
	{
		this.a = a;
		this.b = b;
	}
}
