package graphes;

import personnage.Personnage;

public class Sommet {
	public int id;
	
	public Sommet(){}
	
	public Sommet(int id)
	{
		this.id = id;
	}
	
	public boolean recevoir(Personnage bob)
	{
		bob.setPosition(this);
		return true;
	}
}
