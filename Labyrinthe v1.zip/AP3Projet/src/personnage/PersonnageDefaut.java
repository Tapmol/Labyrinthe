// personnageDefaut.java
// implémentation minimaliste de Personnage
// il sera ensuite conseillé de dériver cette classe afin
// de masquer la methode "faitSonChoix"

package personnage;
import graphes.Sommet;

import java.util.*;
import java.io.*;


import labyrinthe.Salle;

public abstract class PersonnageDefaut implements Personnage {
    private Sommet salleCourante;
    public boolean peutSeDeplacer=true;
    
    public PersonnageDefaut(){}
    
    public abstract Sommet faitSonChoix(Collection<Sommet> sallesAccessibles);

	public Sommet getPosition() {
		return salleCourante;
	}

	public void setPosition(Sommet salleCourante) {
		this.salleCourante = salleCourante;
	}
}
