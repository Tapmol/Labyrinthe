// Personnage.java
package personnage;
import graphes.Sommet;

import java.util.*;


public interface Personnage {
    // renvoie une salle parmi sallesAccesibles
    public Sommet faitSonChoix(Collection<Sommet> sallesAccessibles);

    // renvoie sa position courante
    public Sommet getPosition();
    
    // definit sa position courante
    public void setPosition( Sommet s);
    
}
