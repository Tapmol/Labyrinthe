package labyrinthe.graphe;

import java.io.File;
import java.util.*;

import labyrinthe.Labyrinthe;
import labyrinthe.grille.LabyrintheGrille;
import graphes.Arc;
import graphes.Sommet;

public class LabyrintheGrapheGrille extends LabyrintheGraphe implements LabyrintheGrille
{

	public LabyrintheGrapheGrille(Labyrinthe laby) {
		super(laby);
		// TODO Auto-generated constructor stub
	}

	protected int hauteur;
	protected int largeur;
    

	
	public void creerLabyrinthe(String file){
		Scanner sc=null;
		try
		{
		    sc = new Scanner(new File(file));
		}
		catch(Exception e){ System.out.println(e);}


		hauteur = sc.nextInt();
		largeur = sc.nextInt();
		//salles = new SalleCarree[hauteur][largeur];

		// les deux entiers suivants
		// coord entree
		int ligneEntree=sc.nextInt();
		int colonneEntree=sc.nextInt();
		entree = new SalleSommetCarree(ligneEntree,colonneEntree);
		// les deux entiers suivants
		// coord sortie
		int ligneSortie=sc.nextInt();
		int colonneSortie=sc.nextInt();
		sortie = new SalleSommetCarree(ligneSortie,colonneSortie);
		
		sommets.add(entree);
		sommets.add(sortie);
		
		while(sc.hasNext())
		{
			int ligne=sc.nextInt();
			int colonne=sc.nextInt();
			sommets.add(new SalleSommetCarree(ligne, colonne));
		}
		n = sommets.size();
		
		for (Iterator iterator1 = sommets.iterator(); iterator1.hasNext();)
		{
			Sommet u = (Sommet)iterator1.next();
			for (Iterator iterator2 = sommets.iterator(); iterator2.hasNext();)
			{
				Sommet v = (Sommet)iterator2.next();
				int d = Math.abs(((SalleSommetCarree)u).getColonne() - ((SalleSommetCarree)v).getColonne());
				d+=Math.abs(((SalleSommetCarree)u).getLigne()-((SalleSommetCarree)v).getLigne());
				if (d==1)
				{
					Arc e = new Arc(u,v);
					arcs.add(e);
				}
			}
		}
	}
	
	public int getHauteur()
	{
		return hauteur;
	}
	
	public int getLargeur()
	{
		return largeur;
	}

}