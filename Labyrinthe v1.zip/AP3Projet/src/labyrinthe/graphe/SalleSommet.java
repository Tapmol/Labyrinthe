package labyrinthe.graphe;

import graphes.Sommet;
import labyrinthe.Salle;

public class SalleSommet extends Sommet implements Salle
{
	private int x;
	private int y;
    private int parcouru;
    private Sommet sallePrecedente;
	
	public SalleSommet (int ligne, int colonne)
	{
		this.x=ligne;
		this.y=colonne;
	}
	
	 public void setParcouru(int parcouru)
	 {
	  	this.parcouru = parcouru;
	 }
	   
	 public int getParcouru()
	 {
	  	return parcouru;
	 }
	    
	 public void setSallePrecedente(Sommet sallePrecedente)
	 {
	 	this.sallePrecedente = sallePrecedente;
	 }
	 
	 public Sommet getSallePrecedente()
	 {
	 	return sallePrecedente;
	 }
	 
	 public int getLigne()
	 {
	  	return x;
	 }
	    
	 public int getColonne()
	 {
	  	return y;
	 }

	
}
