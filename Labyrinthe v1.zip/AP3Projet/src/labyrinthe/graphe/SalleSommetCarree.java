package labyrinthe.graphe;

import labyrinthe.grille.Case;

public class SalleSommetCarree extends SalleSommet implements Case
{
	
	public SalleSommetCarree(int ligne, int colonne)
	{
		super(ligne, colonne);
	}
	
	private int x;
    private int y;
    

    
 /*   public boolean recevoir(Personnage bob)
    {
    	if(((PersonnageDefaut) bob).peutSeDeplacer == true)
    	{
    		bob.setPosition(this);
    		return true;
    	}
    	return false;
	}*/
    
    public int getLigne(){
    	return x;
    }
    
    public int getColonne(){
    	return y;
    }
    public String toString(){
		return "Salle: "+x+","+y;
	}
}
