package labyrinthe.graphe;

import java.util.*;
import personnage.*;
import labyrinthe.*;
import labyrinthe.grille.LabyrintheGrilleDefaut;
import graphes.*;

public abstract class LabyrintheGraphe extends Graphe implements Labyrinthe
{

	public LabyrintheGraphe(Labyrinthe laby) {
		super(laby);
		// TODO Auto-generated constructor stub
	}

	protected SalleSommet entree;
	protected SalleSommet sortie;
	

	
	public abstract void creerLabyrinthe(String file);
	
	
	public void entrer(Personnage bob)
	{
		((Sommet) entree).recevoir(bob);
	}
	
	public boolean sortir(Personnage bob)
	{
		return (bob.getPosition()==sortie);
	}
	
	public Collection<Sommet> sallesAccessibles(Sommet bob)
	{
		Collection<Sommet> sa = new ArrayList<Sommet>();
		SalleSommet s = (SalleSommet) bob;
		for (Iterator iterator = sommets.iterator(); iterator.hasNext();)
		{
			Sommet u = (Sommet)iterator.next();
			if(estAdjacent(u,s))
				sa.add((Sommet) u);
		}
		return sa;
	}
	
	public Collection<Sommet> getSommets()
	{
		return sommets;
	}
	
	public SalleSommet getEntree()
	{
		return entree;
	}
	
	public SalleSommet getSortie()
	{
		return sortie;
	}
}
