package labyrinthe.grille;

import graphes.Sommet;

import java.io.File;
import java.util.*;

import labyrinthe.graphe.SalleSommet;
import personnage.Personnage;

public class LabyrintheGrilleDefaut implements LabyrintheGrille
{

	protected int hauteur;
    protected int largeur;
    protected SalleSommet[][] sommets;
    protected SalleSommet entree;
    protected SalleSommet sortie;
    
    // cree le labyrinthe
    public void creerLabyrinthe(String file)
    {
		// À parir d'un fichier !
		Scanner sc=null;
		try
		{
		    sc = new Scanner(new File(file));
		}
		catch(Exception e){ System.out.println(e);}
	
		// les deux premiers entiers
		// hauteur largeur
		hauteur=sc.nextInt();
		largeur=sc.nextInt();
		sommets = new SalleSommet[hauteur][largeur];
	
		// les deux entiers suivants
		// coord entree
		int ligneEntree=sc.nextInt();
		int colonneEntree=sc.nextInt();
		entree = new SalleSommet(ligneEntree,colonneEntree);
		// les deux entiers suivants
		// coord sortie
		int ligneSortie=sc.nextInt();
		int colonneSortie=sc.nextInt();
		sortie = new SalleSommet(ligneSortie,colonneSortie);
	
		// on initialise la matrice
		// null signifie : salle non existante
		for(int i=0;i<hauteur;i++)
		    for(int j=0;j<largeur;j++)
			sommets[i][j]=null;
		
		// ajout des entree et sortie
		sommets[ligneEntree][colonneEntree]=entree;
		sommets[ligneSortie][colonneSortie]=sortie;
	
		// ajout des autres salles
		while(sc.hasNext())
		{
		    int ligne=sc.nextInt();
		    int colonne=sc.nextInt();
		    sommets[ligne][colonne]=new SalleSommet(ligne,colonne);
		}
    }
    

    // renvoie les salles accessibles par bob
    public Collection<Sommet> sallesAccessibles(Sommet bob)
    {
    	Collection<Sommet> sa = new ArrayList<Sommet>();
    	SalleSommet tmp=(SalleSommet) bob;
    	SalleSommet ad;
    	try
    	{
    		ad=sommets[tmp.getLigne()-1][tmp.getColonne()];
    		if(ad != null)
    			sa.add(ad); // haut
    		ad=sommets[tmp.getLigne()][tmp.getColonne()+1];
    		if(ad != null)
    			sa.add(ad); // droite
    		ad=sommets[tmp.getLigne()+1][tmp.getColonne()];
    		if(ad != null)
    			sa.add(ad); // bas 
    		ad=sommets[tmp.getLigne()][tmp.getColonne()-1];
    		if(ad != null)
    			sa.add(ad); // gauche
    	}
    	catch(Exception e){}
    	return sa;
    }


    public Collection<Sommet> getSommets()
    {
    	ArrayList<Sommet> al = new ArrayList<Sommet>();
    	for (int i=0; i<getHauteur(); i++)
    		for (int j=0; j<getLargeur(); j++)
    			if (sommets[i][j]!=null)
    				al.add(sommets[i][j]);
    	return al;
    }
    
    public int getHauteur()
    {
    	return hauteur;
    }

    public int getLargeur()
    {
    	return largeur;
    }
    

	public void entrer(Personnage bob)
	{
    	entree.recevoir(bob);
    }

    public boolean sortir(Personnage bob){
		return (bob.getPosition()==sortie);
    }

	public Sommet getEntree(){
		return entree;
	}

	public Sommet getSortie(){
		return sortie;
	}

}
