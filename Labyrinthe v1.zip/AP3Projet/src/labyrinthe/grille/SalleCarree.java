package labyrinthe.grille;

import labyrinthe.Salle;
import personnage.*;

public class SalleCarree implements Case{
	private int x;
    private int y;
    private int parcouru;
    private Salle sallePrecedente;
    
    public SalleCarree(int colonne,int ligne)
    {
    	this.x=colonne;
    	this.y=ligne;
    }
    
    public boolean recevoir(Personnage bob)
    {
    	if(((PersonnageDefaut) bob).peutSeDeplacer == true)
    	{
    		//bob.setPosition(this);
    		return true;
    	}
    	return false;
	}
    
    public void setParcouru(int parcouru)
    {
    	this.parcouru = parcouru;
    }
    
    public int getParcouru()
    {
    	return parcouru;
    }
    
    public void setSallePrecedente(Salle sallePrecedente)
    {
    	this.sallePrecedente = sallePrecedente;
    }
    
    public Salle getSallePrecedente()
    {
    	return sallePrecedente;
    }
    
    public int getLigne()
    {
    	return x;
    }
    
    public int getColonne()
    {
    	return y;
    }
    public String toString()
    {
		return "Salle: "+x+","+y;
	}
}
