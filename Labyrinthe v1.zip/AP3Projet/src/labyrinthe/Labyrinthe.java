// Labyrinthe.java
package labyrinthe;
import graphes.Sommet;

import java.util.*;
import personnage.Personnage;

public interface Labyrinthe {
    // cree le labyrinthe
    public abstract void creerLabyrinthe(String file);
    
    // place bob à l'entree du labyrinthe
    public abstract void entrer(Personnage bob);

    // dit si bob est sorti
    public abstract boolean sortir(Personnage bob);

    // renvoie les salles accessibles par bob
    public abstract Collection<Sommet> sallesAccessibles(Sommet bob);
    
    // accesseur sur les salles du labyrinthes
    public abstract Collection<Sommet> getSommets();
    
    // accesseurs sur l'entree et la sortie
    public abstract Sommet getEntree();
    public abstract Sommet getSortie();
}
