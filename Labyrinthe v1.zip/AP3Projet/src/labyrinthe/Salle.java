package labyrinthe;

import personnage.Personnage;

public interface Salle
{
	public abstract boolean recevoir(Personnage bob);
}
