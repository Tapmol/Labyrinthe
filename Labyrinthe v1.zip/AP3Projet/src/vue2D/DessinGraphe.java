package vue2D;

import graphes.Sommet;

import java.awt.Color;
import java.awt.Graphics;

import labyrinthe.graphe.SalleSommet;
import labyrinthe.grille.Case;
import labyrinthe.grille.LabyrintheGrille;
import personnage.Personnage;
import graphes.*;

public class DessinGraphe extends Dessin
{
	public DessinGraphe(LabyrintheGrille labyrinthe, Personnage bob)
	{
		super(labyrinthe, bob);
	}
	
	public void dessinPlusCourtChemin(Graphics g)
	{
		Sommet c = (Sommet)bob.getPosition();
		for (Sommet s : ((Graphe)labyrinthe).plusCourtChemin(c,((Sommet)sortie)))
		{
			int i = ((Case)s).getLigne();
			int j = ((Case)s).getColonne();
			g.setColor(new Color(255,0,0));
			g.fillRect(j*unite, i*unite, unite, unite);
		}
	}
	
	
	
/*	public void dessinEclairage(Graphics g)
	{
		Sommet c = (Sommet)bob.getPosition();
		for (Sommet s : ((Graphe)labyrinthe).sommets)
		{
			int i = ((Case)s).getLigne();
			int j = ((Case)s).getColonne();
			int dist = ((Graphe)labyrinthe).distances[c.id][s.id];
			if(dist<9)
			{
				g.setColor(new Color(255-dist*20, 215-dist*20,dist*5));
				g.fillRect(j*unite, i*unite, unite, unite);
			}
		}
	}*/
	
	


	public void paintComponent(Graphics g)
    {
		dessinFond(g);
    	dessinSalles(g);
    	dessinSallesVisitees(g);
    	dessinEntreeSortie(g);
    	dessinHeros(g);
    	dessinPlusCourtChemin(g);
    //	dessinEclairage(g);

    }
}
