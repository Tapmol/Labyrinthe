// LabyrintheApp.java
package application;
import graphes.Sommet;

import java.util.*;
import javax.swing.*;

import personnage.*;
import labyrinthe.Labyrinthe;
import labyrinthe.graphe.*;
import labyrinthe.grille.Case;

import vue2D.*;

public class LabyrintheApp
{

	public LabyrintheApp(Labyrinthe laby)
	{}
	
    public static void main (String[] args)
    {
		// modele
		LabyrintheGraphe labyrinthe = new LabyrintheGrapheGrille();
		if (args.length==0)
			labyrinthe.creerLabyrinthe("labys/laby3.txt");
		else
			labyrinthe.creerLabyrinthe(args[0]);
		Personnage bob = new PersonnageClavier();
		labyrinthe.entrer(bob);
		int cpt=0;

		// vue
		JFrame.setDefaultLookAndFeelDecorated(true);
		JFrame frame = new JFrame("Labyrinthe");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dessin dessin = new DessinGraphe((LabyrintheGrapheGrille)labyrinthe,bob);

		//position graphique initiale du héros
		Case s = (Case) bob.getPosition();
		((PersonnageClavier) bob).xpix = s.getColonne()*dessin.unite;
		((PersonnageClavier) bob).ypix = s.getLigne()*dessin.unite;
		
		dessin.setFocusable(true);
		dessin.requestFocus();
		frame.setContentPane(dessin);
		frame.pack();
		frame.setVisible(true);
	
		while(!labyrinthe.sortir(bob))
		{
		    Collection<Sommet> sallesAccessibles = labyrinthe.sallesAccessibles((Sommet) bob.getPosition());
		    Sommet destination = bob.faitSonChoix(sallesAccessibles); // on demande au heros de faire son choix de salle
		    if (destination!=bob.getPosition()) destination.recevoir(bob); // deplacement
		    //rafraichissement de la vue
		    frame.repaint();
		    // on fait une pause
		    try{Thread.currentThread().sleep(10);}
		    catch(InterruptedException ie){}
		    
		}
    }
}
